package exercice1;

public class CombinaisonLinaire {

	
}
